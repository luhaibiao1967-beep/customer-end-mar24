// src/supabaseClient.js
import { createClient } from "@supabase/supabase-js";

const supabaseUrl = "https://jzdnvdebwmuebjbergsp.supabase.co";
const supabaseAnonKey = "sb_publishable_NIcyg4d4vRthPzPMGNj7zg_foZk65y2"

export const supabase = createClient(supabaseUrl, supabaseAnonKey);
